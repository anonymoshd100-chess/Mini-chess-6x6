# Mini Chess 6x6 — Pro Arena 2.0

A Node.js + Socket.IO starter for real-time 1v1 online Mini Chess on a 6×6 board.

## Requirements
- Node.js 18 or newer
- npm

## Run locally
1. Install Node.js.
2. Extract this folder.
3. Open a terminal in this folder.
4. Run:

   ```bash
   npm install
   npm start
   ```

5. Open `http://localhost:3000` in your browser.
6. Open the same address in a second browser/device on the same network to test matchmaking.

## How online matchmaking works
- A player enters a nickname and joins the queue.
- The next player joining is paired with them.
- White moves first.
- All submitted moves are checked on the server.
- The board updates live through Socket.IO.

## Important limitations in this starter
- This is a playable online foundation, not a complete Chess.com replacement.
- Accounts, passwords, ratings, saved match history, chat, tournaments, and persistent leaderboards are not included.
- Player names are temporary guest names. No personal information is needed.
- Games are held in server memory and disappear when the server restarts.
- A disconnected player ends the active match.
- 6×6 rules here omit castling and en passant. Pawns promote automatically to queens.
- The client displays legal-move hints, while the server remains authoritative for move validation.
- For public deployment, add HTTPS, rate limiting, persistent storage, account security, abuse protection, and production hosting.

## Deploying for friends
Run the app on a Node.js host that supports WebSockets. Set the host's `PORT` environment variable if required. Share the deployed HTTPS address with players. Do not expose a development computer directly to the public internet without appropriate network and security setup.
