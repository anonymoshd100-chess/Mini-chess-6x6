const express = require("express");
const http = require("http");
const { Server } = require("socket.io");
const crypto = require("crypto");

const app = express();
const server = http.createServer(app);
const io = new Server(server);
const PORT = process.env.PORT || 3000;

app.use(express.static("public"));
app.get("/health", (_req, res) => res.json({ ok: true, name: "Mini Chess 6x6" }));

const waiting = [];
const games = new Map();
const playerGame = new Map();

const START = [
  ["r","n","b","q","k","r"],
  ["p","p","p","p","p","p"],
  [null,null,null,null,null,null],
  [null,null,null,null,null,null],
  ["P","P","P","P","P","P"],
  ["R","N","B","Q","K","R"]
];

const clone = board => board.map(row => row.slice());
const inside = (r,c) => r >= 0 && r < 6 && c >= 0 && c < 6;
const isWhite = p => p && p === p.toUpperCase();
const sameSide = (a,b) => a && b && isWhite(a) === isWhite(b);

function findKing(board, white) {
  const king = white ? "K" : "k";
  for (let r=0;r<6;r++) for (let c=0;c<6;c++) if (board[r][c] === king) return [r,c];
  return null;
}

function attacked(board, r, c, byWhite) {
  const pawn = byWhite ? "P" : "p";
  const pawnSourceRow = r + (byWhite ? 1 : -1);
  for (const dc of [-1,1]) {
    const cc = c + dc;
    if (inside(pawnSourceRow,cc) && board[pawnSourceRow][cc] === pawn) return true;
  }
  const knight = byWhite ? "N" : "n";
  for (const [dr,dc] of [[-2,-1],[-2,1],[-1,-2],[-1,2],[1,-2],[1,2],[2,-1],[2,1]]) {
    const rr=r+dr, cc=c+dc;
    if (inside(rr,cc) && board[rr][cc] === knight) return true;
  }
  const king = byWhite ? "K" : "k";
  for (let dr=-1;dr<=1;dr++) for (let dc=-1;dc<=1;dc++) {
    if (!dr && !dc) continue;
    const rr=r+dr, cc=c+dc;
    if (inside(rr,cc) && board[rr][cc] === king) return true;
  }
  const rays = [
    {dirs:[[1,0],[-1,0],[0,1],[0,-1]], pieces: byWhite ? ["R","Q"] : ["r","q"]},
    {dirs:[[1,1],[1,-1],[-1,1],[-1,-1]], pieces: byWhite ? ["B","Q"] : ["b","q"]}
  ];
  for (const ray of rays) for (const [dr,dc] of ray.dirs) {
    let rr=r+dr, cc=c+dc;
    while (inside(rr,cc)) {
      const p=board[rr][cc];
      if (p) { if (ray.pieces.includes(p)) return true; break; }
      rr+=dr; cc+=dc;
    }
  }
  return false;
}

function inCheck(board, white) {
  const king = findKing(board, white);
  return !king || attacked(board, king[0], king[1], !white);
}

function pseudoMoves(board, r, c) {
  const p=board[r][c];
  if (!p) return [];
  const white=isWhite(p), kind=p.toLowerCase(), out=[];
  const add=(rr,cc) => {
    if (!inside(rr,cc)) return false;
    const target=board[rr][cc];
    if (target && sameSide(p,target)) return false;
    out.push({from:[r,c],to:[rr,cc]});
    return !target;
  };
  if (kind==="p") {
    const dir=white?-1:1, nr=r+dir;
    if (inside(nr,c) && !board[nr][c]) {
      out.push({from:[r,c],to:[nr,c]});
      for (const dc of [-1,1]) {
        const nc=c+dc;
        if (inside(nr,nc) && board[nr][nc] && !sameSide(p,board[nr][nc]))
          out.push({from:[r,c],to:[nr,nc]});
      }
    } else {
      for (const dc of [-1,1]) {
        const nc=c+dc;
        if (inside(nr,nc) && board[nr][nc] && !sameSide(p,board[nr][nc]))
          out.push({from:[r,c],to:[nr,nc]});
      }
    }
  } else if (kind==="n") {
    for (const [dr,dc] of [[-2,-1],[-2,1],[-1,-2],[-1,2],[1,-2],[1,2],[2,-1],[2,1]]) add(r+dr,c+dc);
  } else if (kind==="k") {
    for (let dr=-1;dr<=1;dr++) for (let dc=-1;dc<=1;dc++) if (dr||dc) add(r+dr,c+dc);
  } else {
    const dirs=[];
    if (kind==="r" || kind==="q") dirs.push([1,0],[-1,0],[0,1],[0,-1]);
    if (kind==="b" || kind==="q") dirs.push([1,1],[1,-1],[-1,1],[-1,-1]);
    for (const [dr,dc] of dirs) {
      let rr=r+dr,cc=c+dc;
      while (inside(rr,cc)) { const clear=add(rr,cc); if (!clear) break; rr+=dr; cc+=dc; }
    }
  }
  return out;
}

function applyMove(board, move) {
  const next=clone(board);
  const [fr,fc]=move.from, [tr,tc]=move.to;
  let piece=next[fr][fc];
  next[fr][fc]=null;
  if (piece==="P" && tr===0) piece="Q";
  if (piece==="p" && tr===5) piece="q";
  next[tr][tc]=piece;
  return next;
}

function legalMoves(board, white) {
  const moves=[];
  for (let r=0;r<6;r++) for (let c=0;c<6;c++) {
    const p=board[r][c];
    if (p && isWhite(p)===white) {
      for (const move of pseudoMoves(board,r,c)) {
        const next=applyMove(board,move);
        if (!inCheck(next,white)) moves.push(move);
      }
    }
  }
  return moves;
}

function publicState(game) {
  return {
    id: game.id,
    board: game.board,
    turn: game.turn,
    status: game.status,
    winner: game.winner,
    players: {
      white: { name: game.names.white, connected: game.connected.white },
      black: { name: game.names.black, connected: game.connected.black }
    },
    history: game.history,
    check: inCheck(game.board, game.turn)
  };
}

function removeFromQueue(socketId) {
  const i=waiting.findIndex(p=>p.id===socketId);
  if (i>=0) waiting.splice(i,1);
}

function finishIfNeeded(game) {
  const moves=legalMoves(game.board,game.turn);
  if (moves.length===0) {
    if (inCheck(game.board,game.turn)) {
      game.status="checkmate";
      game.winner=game.turn ? "black" : "white";
    } else {
      game.status="draw";
      game.winner=null;
    }
  }
}

function sendState(game) {
  const state=publicState(game);
  io.to(game.id).emit("game:state",state);
}

io.on("connection", socket => {
  socket.on("queue:join", rawName => {
    removeFromQueue(socket.id);
    const name=String(rawName || "Guest").trim().replace(/[<>]/g,"").slice(0,18) || "Guest";
    if (playerGame.has(socket.id)) return;
    const opponentIndex=waiting.findIndex(p=>p.id!==socket.id);
    if (opponentIndex<0) {
      waiting.push({id:socket.id,name});
      socket.emit("queue:waiting");
      return;
    }
    const opponent=waiting.splice(opponentIndex,1)[0];
    const id=crypto.randomUUID();
    const game={
      id, board:clone(START), turn:true, status:"playing", winner:null,
      names:{white:opponent.name,black:name},
      sockets:{white:opponent.id,black:socket.id},
      connected:{white:true,black:true}, history:[]
    };
    games.set(id,game);
    playerGame.set(opponent.id,id);
    playerGame.set(socket.id,id);
    const other=io.sockets.sockets.get(opponent.id);
    if (other) { other.join(id); other.emit("game:started",{color:"white",state:publicState(game)}); }
    socket.join(id);
    socket.emit("game:started",{color:"black",state:publicState(game)});
    sendState(game);
  });

  socket.on("queue:leave",()=>removeFromQueue(socket.id));

  socket.on("move:make", payload => {
    const gameId=playerGame.get(socket.id);
    const game=games.get(gameId);
    if (!game || game.status!=="playing") return;
    const color=game.sockets.white===socket.id ? "white" : "black";
    if ((game.turn && color!=="white") || (!game.turn && color!=="black")) {
      socket.emit("game:error","It is not your turn.");
      return;
    }
    const from=payload && payload.from, to=payload && payload.to;
    if (!Array.isArray(from)||!Array.isArray(to)||from.length!==2||to.length!==2 ||
        !from.every(Number.isInteger)||!to.every(Number.isInteger)) return;
    const move=legalMoves(game.board,game.turn).find(m=>m.from[0]===from[0]&&m.from[1]===from[1]&&m.to[0]===to[0]&&m.to[1]===to[1]);
    if (!move) { socket.emit("game:error","That move is not legal."); return; }
    const [fr,fc]=move.from,[tr,tc]=move.to;
    const piece=game.board[fr][fc], captured=game.board[tr][tc];
    game.board=applyMove(game.board,move);
    game.history.push({piece,from,to,captured,notation:`${piece.toUpperCase()} ${String.fromCharCode(97+fc)}${6-fr} → ${String.fromCharCode(97+tc)}${6-tr}`});
    game.turn=!game.turn;
    finishIfNeeded(game);
    sendState(game);
  });

  socket.on("game:resign",()=>{
    const game=games.get(playerGame.get(socket.id));
    if (!game || game.status!=="playing") return;
    const color=game.sockets.white===socket.id?"white":"black";
    game.status="resigned"; game.winner=color==="white"?"black":"white";
    sendState(game);
  });

  socket.on("disconnect",()=>{
    removeFromQueue(socket.id);
    const game=games.get(playerGame.get(socket.id));
    if (game) {
      const color=game.sockets.white===socket.id?"white":"black";
      game.connected[color]=false;
      if (game.status==="playing") game.status="opponent_disconnected";
      sendState(game);
      const otherColor=color==="white"?"black":"white";
      const otherId=game.sockets[otherColor];
      io.to(otherId).emit("game:notice","Your opponent disconnected. This game has ended.");
      playerGame.delete(game.sockets.white);
      playerGame.delete(game.sockets.black);
      games.delete(game.id);
    }
  });
});

server.listen(PORT,()=>console.log(`Mini Chess 6x6 running at http://localhost:${PORT}`));
