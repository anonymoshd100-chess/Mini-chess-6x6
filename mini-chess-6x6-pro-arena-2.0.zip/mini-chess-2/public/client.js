const socket = io();
const $ = id => document.getElementById(id);
const screens = ["welcome","waiting","game","result"];
let myColor = null, gameState = null, selected = null, legalTargets = [], lastMove = null, playerName = "Guest";

function showScreen(name) { screens.forEach(id => $(id).classList.toggle("hidden",id!==name)); }
function setMessage(msg) { $("welcomeMsg").textContent=msg; }
function pieceSymbol(p) {
  return ({K:"♔",Q:"♕",R:"♖",B:"♗",N:"♘",P:"♙",k:"♚",q:"♛",r:"♜",b:"♝",n:"♞",p:"♟"})[p] || "";
}
function isMine(p) { return p && (myColor==="white" ? p===p.toUpperCase() : p===p.toLowerCase()); }
function coordsForView(r,c) { return myColor==="white" ? [r,c] : [5-r,5-c]; }

function renderBoard() {
  const board=$("board"); board.innerHTML="";
  if (!gameState) return;
  for (let vr=0;vr<6;vr++) for (let vc=0;vc<6;vc++) {
    const [r,c]=coordsForView(vr,vc), p=gameState.board[r][c];
    const sq=document.createElement("button");
    sq.className="square "+((vr+vc)%2===0?"light":"dark");
    if (p) sq.classList.add(p===p.toUpperCase()?"white-piece":"black-piece");
    if (selected && selected[0]===r && selected[1]===c) sq.classList.add("selected");
    if (lastMove && ((lastMove.from[0]===r&&lastMove.from[1]===c)||(lastMove.to[0]===r&&lastMove.to[1]===c))) sq.classList.add("last");
    if (legalTargets.some(m=>m.to[0]===r&&m.to[1]===c)) sq.classList.add(p?"capture":"legal");
    if (p && p.toLowerCase()==="k" && gameState.check && ((gameState.turn&&p==="K")||(!gameState.turn&&p==="k"))) sq.classList.add("check");
    sq.textContent=pieceSymbol(p);
    sq.setAttribute("aria-label",`${String.fromCharCode(97+c)}${6-r} ${p||"empty"}`);
    sq.addEventListener("click",()=>clickSquare(r,c));
    board.appendChild(sq);
  }
}
function clickSquare(r,c) {
  if (!gameState || gameState.status!=="playing") return;
  const myTurn=(myColor==="white"&&gameState.turn)||(myColor==="black"&&!gameState.turn);
  if (!myTurn) return;
  const p=gameState.board[r][c];
  if (selected && legalTargets.some(m=>m.to[0]===r&&m.to[1]===c)) {
    socket.emit("move:make",{from:selected,to:[r,c]});
    selected=null; legalTargets=[]; renderBoard(); return;
  }
  if (p && isMine(p)) {
    selected=[r,c];
    // The server is authoritative; legal destinations are requested from the current state.
    legalTargets=clientLegalMoves(gameState.board,r,c);
  } else { selected=null; legalTargets=[]; }
  renderBoard();
}

// Client-side move hints mirror the supported 6x6 rules. The server validates every submitted move.
function clientLegalMoves(b,r,c) {
  const p=b[r][c], white=p===p.toUpperCase(), kind=p.toLowerCase(), out=[];
  const add=(rr,cc)=>{if(rr<0||rr>5||cc<0||cc>5)return false;const t=b[rr][cc];if(t&&((t===t.toUpperCase())===white))return false;out.push({to:[rr,cc]});return !t;};
  if(kind==="p"){const d=white?-1:1,nr=r+d;if(nr>=0&&nr<6&&!b[nr][c])out.push({to:[nr,c]});for(const dc of [-1,1]){const nc=c+dc;if(nr>=0&&nr<6&&nc>=0&&nc<6&&b[nr][nc]&&((b[nr][nc]===b[nr][nc].toUpperCase())!==white))out.push({to:[nr,nc]});}}
  else if(kind==="n"){for(const [dr,dc] of [[-2,-1],[-2,1],[-1,-2],[-1,2],[1,-2],[1,2],[2,-1],[2,1]])add(r+dr,c+dc);}
  else if(kind==="k"){for(let dr=-1;dr<=1;dr++)for(let dc=-1;dc<=1;dc++)if(dr||dc)add(r+dr,c+dc);}
  else {const dirs=[];if(kind==="r"||kind==="q")dirs.push([1,0],[-1,0],[0,1],[0,-1]);if(kind==="b"||kind==="q")dirs.push([1,1],[1,-1],[-1,1],[-1,-1]);for(const [dr,dc] of dirs){let rr=r+dr,cc=c+dc;while(rr>=0&&rr<6&&cc>=0&&cc<6){const clear=add(rr,cc);if(!clear)break;rr+=dr;cc+=dc;}}}
  return out.map(m=>({from:[r,c],to:m.to}));
}

function renderState(state) {
  gameState=state; selected=null; legalTargets=[];
  $("opponentName").textContent=state.players[myColor==="white"?"black":"white"].name;
  $("yourName").textContent=state.players[myColor].name;
  $("yourColor").textContent=myColor.toUpperCase();
  $("opponentState").textContent=state.players[myColor==="white"?"black":"white"].connected?"CONNECTED":"OFFLINE";
  const myTurn=(myColor==="white"&&state.turn)||(myColor==="black"&&!state.turn);
  $("yourState").textContent=myTurn?"YOUR TURN":"WAITING";
  $("turnText").textContent=state.status==="playing"?(myTurn?"Your turn — make a move.":`${state.players[myColor==="white"?"black":"white"].name} is thinking…`):"Match finished.";
  $("history").innerHTML="";
  state.history.forEach((m,i)=>{const li=document.createElement("li");li.textContent=`${i+1}. ${m.notation}`;$("history").appendChild(li);});
  if(state.history.length) lastMove=state.history[state.history.length-1];
  renderBoard();
  if(["checkmate","draw","resigned","opponent_disconnected"].includes(state.status)) showResult(state);
}
function showResult(state) {
  const won=state.winner===myColor;
  $("resultTitle").textContent=state.status==="draw"?"Draw":won?"Victory!":"Game over";
  $("resultText").textContent=state.status==="draw"?"No legal moves remain. The match is a draw.":state.status==="opponent_disconnected"?"Your opponent disconnected.":won?"You won the match.":"Your opponent won the match.";
  showScreen("result");
}

$("playBtn").addEventListener("click",()=>{
  playerName=$("playerName").value.trim().replace(/[<>]/g,"").slice(0,18)||"Guest";
  $("playerName").value=playerName;
  setMessage("Connecting to the arena…");
  socket.emit("queue:join",playerName);
});
$("cancelBtn").addEventListener("click",()=>{socket.emit("queue:leave");showScreen("welcome");setMessage("Search cancelled.");});
$("resignBtn").addEventListener("click",()=>{if(confirm("Resign this match?"))socket.emit("game:resign");});
$("homeBtn").addEventListener("click",()=>{if(confirm("Leave this match and return to the lobby?")){socket.disconnect();socket.connect();gameState=null;showScreen("welcome");}});
$("againBtn").addEventListener("click",()=>{gameState=null;myColor=null;showScreen("welcome");setMessage("Ready for another match.");});
$("rulesBtn").addEventListener("click",()=>$("rulesModal").classList.remove("hidden"));
$("closeRules").addEventListener("click",()=>$("rulesModal").classList.add("hidden"));
$("gotIt").addEventListener("click",()=>$("rulesModal").classList.add("hidden"));

socket.on("connect",()=>setMessage("Connected. No account required."));
socket.on("queue:waiting",()=>showScreen("waiting"));
socket.on("game:started",data=>{myColor=data.color;lastMove=null;showScreen("game");renderState(data.state);});
socket.on("game:state",state=>{if(!myColor)return;renderState(state);});
socket.on("game:error",msg=>{ $("turnText").textContent=msg; });
socket.on("game:notice",msg=>{ $("turnText").textContent=msg; });
socket.on("disconnect",()=>{if(!$("game").classList.contains("hidden")){showScreen("welcome");setMessage("Connection lost. Refresh the page to reconnect.");}});
